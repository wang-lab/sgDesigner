from numpy import random, array, zeros, empty
import os
from sklearn.model_selection import KFold
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from xgboost import XGBClassifier

def readTrain(filename):
	data = open(filename,"r")
	lines = data.readlines()
	header = lines[0]
	header = header.strip()
	headers = header.split("\t")
	positions = [headers.index(i) for i in headers if 'class1' in i]
	startpoint = positions[0]
	lines.pop(0)

	random.seed(12345)
	random.shuffle(lines)

	data_feature = []
	data_label = []
	data_expression = []

	for line in lines:
		line = line.strip()
		elements = line.split("\t")
		label = float(elements[0])
		expression = float(elements[1])
		features = [float(elements[i]) for i in range(startpoint, len(elements))]

		data_feature.append(features)
		data_label.append(label)
		data_expression.append(expression)

	data_feature = array(data_feature)
	data_label = array(data_label)
	data_expression = array(data_expression)

	return data_feature, data_label, data_expression


def readTest(filename):
	data = open(filename, "r")
	lines = data.readlines()

	data_feature = []

	for line in lines:
		line = line.strip()
		elements = line.split("\t")
		features = [float(elements[i]) for i in range(0, len(elements))]
		data_feature.append(features)

	data_feature = array(data_feature)

	return data_feature


def getRange(feature):
	feature_range = zeros((feature.shape[1], 2))

	for i in range(0, feature.shape[1]):
		col = feature[:, i]
		min_val = float(min(col))
		max_val = float(max(col))
		feature_range[i, :] = [min_val, max_val]

	return feature_range


def svm_scale(feature, ranges, lower, upper):
	feature_scaled = zeros((feature.shape[0], feature.shape[1]))

	for i in range(0, feature.shape[1]-1):
		feat = feature[:, i]
		min_val = ranges[i, 0]
		max_val = ranges[i, 1]
		if ((max_val - min_val) != 0):
			feat_std = (feat - min_val) / (max_val - min_val)
			feature_scaled[:, i] = feat_std * (upper - lower) + lower
		else:
			feature_scaled[:, i] = zeros((feature.shape[0],))

	return feature_scaled


def firstLayer(classifier, features_train, label_train, features_test):
	ntrain = features_train.shape[0]
	ntest = features_test.shape[0]
	nfolds = 5

	fivefold = KFold(n_splits = nfolds)

	oof_train = zeros((ntrain,))
	oof_test = zeros((ntest,))
	oof_test_kf = empty((nfolds, ntest))

	for i, (train_indx, test_indx) in enumerate(fivefold.split(features_train, label_train)):
		x_tr = features_train[train_indx]
		y_tr = label_train[train_indx]
		x_te = features_train[test_indx]

		classifier.fit(x_tr, y_tr)

		oof_train[test_indx] = classifier.predict_proba(x_te)[:, 1]
		oof_test_kf[i, :] = classifier.predict_proba(features_test)[:, 1]

	oof_test[:] = oof_test_kf.mean(axis=0)

	return oof_train, oof_test


def stacking(features_train, label_train, features_test):
	svm = SVC(kernel = 'rbf', probability = True, C = 8.0, gamma = 0.03125)

	boost = XGBClassifier(
			max_depth = 5, learning_rate = 0.1, n_estimators = 250, objective = 'binary:logistic', 
			min_child_weight = 1, gamma = 0.5, subsample = 0.5, colsample_bytree = 0.8
		) # classifier for training inhouse

	second_layer = LogisticRegression(penalty = 'l2', solver = 'lbfgs', max_iter = 10000, C = 0.01)

	ntrain = features_train.shape[0]
	ntest = features_test.shape[0]
	second_train = zeros((ntrain, 2))
	second_test = zeros((ntest, 2))

	train_range = getRange(features_train)
	features_train_scale = svm_scale(features_train, train_range, 0, 1)
	features_test_scale = svm_scale(features_test, train_range, 0, 1)

	oof_train_svm, oof_test_svm = firstLayer(svm, features_train_scale, label_train, features_test_scale)

	second_train[:, 0] = oof_train_svm
	second_test[:, 0] = oof_test_svm

	oof_train_boost, oof_test_boost = firstLayer(boost, features_train, label_train, features_test)
	second_train[:, 1] = oof_train_boost
	second_test[:, 1] = oof_test_boost

	second_layer.fit(second_train, label_train)

	label_pred = second_layer.predict(second_test)
	prob_pred = second_layer.predict_proba(second_test)

	prob_pred = prob_pred[:,1]

	return label_pred, prob_pred

cwd = os.getcwd()
#training dataset
train_file = cwd + "/training_features.txt"
#testing dataset
test_file = cwd + "/temp/custom_features_v1.0.txt"
#result file
result_file = cwd + "/temp/custom_prediction_result_v1.0.txt"

train_feature, train_label, train_expression = readTrain(train_file)
test_feature = readTest(test_file)

label_pred, prob_pred = stacking(train_feature, train_label, test_feature)
prob_pred = [int(i*100+0.5) for i in prob_pred]
prob_pred = [((j - 30.5)/(76 - 30.5) * 100) for j in prob_pred]
prob_pred = [int(k +0.5) for k in prob_pred]


f = open(result_file, 'w')
try:
	f.write("labels\tprobabilities\n")
	for i, (label) in enumerate(label_pred):
		f.write("{}\t{}\n".format(label, prob_pred[i]))

finally:
	f.close()

